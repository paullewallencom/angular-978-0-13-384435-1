var week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
for (var i=0; i<week.length; i++) {
    console.log("<li>" + week[i] + "</li>");
}
for () {
    console.log("<li>" + week[dayIndex] + "</li>");
}