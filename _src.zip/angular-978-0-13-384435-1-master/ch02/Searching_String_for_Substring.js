var myStr = "I think, therefore I am.";
if (myStr.indexOf("think") != -1){
    console.log(myStr);
}