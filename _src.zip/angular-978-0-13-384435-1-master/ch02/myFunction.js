// Defining Functions

function myFunction() {
    console.log("Hello World");
}

myFunction();