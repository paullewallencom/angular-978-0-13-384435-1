var word1 = "Today";
var word2 = "is ";
var word3 = "tomorrow\' ";
var word4 = "yesterday.";
var sentence1 = word1 + word2 + word3 + word4;
var sentence2 = word1.concat(word2, word3, word4);