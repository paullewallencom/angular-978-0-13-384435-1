function message(day) {
    var week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
    if (week.indexOf(day) != -1) {
        console.log("Happy " + day);
    }
}