var timeArr = [12,10,36];
var timeStr = timeArr.join(":");