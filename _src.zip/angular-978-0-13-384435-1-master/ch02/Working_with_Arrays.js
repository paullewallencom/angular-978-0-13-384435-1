var arr = [
  "one"
, "two"
, "three"
];
var arr2 = new Array();
arr2[0] = "one";
arr2[1] = "two";
arr3[2] = "three";
var arr3 = new Array();
arr3.push("one");
arr3.push("two");
arr3.push("three");

// var numOfItems = arr.length;

// var
week = [
  "Monday"
, "Tuesday"
, "Wednesday"
, "Thursday"
, "Friday"
, "Saturday"
, "Sunday"
];
var first = w [0];
var last = week[week.length-1];