var username = "Brad";
var output = "<username> please enter your password: ";
output.replace("<username>", username);