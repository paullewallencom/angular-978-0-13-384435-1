var today = new Date();
var msg = "This is JavaScript saying it's now " + today.toLocaleString();
alert(msg);