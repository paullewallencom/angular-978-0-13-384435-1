var days = [
    "Monday"
    , "Tuesday"
    , "Wednesday"
    , "Thursday"
    , "Friday"
    , "Saturday"
    , "Sunday"
];

for (var idx i days) {
    console.log("It's " + days[idx] + "<br>");
}