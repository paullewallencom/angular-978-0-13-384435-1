// Passing Variables to Functions

function greeting(name, city) {
    console.log("Hello " + name);
    console.log(". How is the weather in " + city);
}

var name = "Brad";
greeting(name, "Florence");