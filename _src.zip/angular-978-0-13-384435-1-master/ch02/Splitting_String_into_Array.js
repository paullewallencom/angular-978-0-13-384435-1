var t      = "12:10:36";
var tArr   = t.split(":");
var hour   = tArr[0];
var minute = tArr[1];
var second = tArr[2];